export interface Testimonial {
  id: string;
  title: string;
  content: string;
  rating: string;
  author: string;
  logoAlt: string;
}

export const testimonials: Testimonial[] = [
  {
    id: "blas-v",
    title: "A New Go-To Company",
    content:
      "First I was working with another transport company and for three days I didn't hear anything. So I contacted Nexus Auto Transport and the communication was outstanding. They communicated with me daily and responded within minutes when I needed them. They transported my 65 mustang from Colorado to Houston in no time.\n    They will be my go-to auto transport company from now on.",
    rating: "5.0",
    author: "Blas V.",
    logoAlt: "google-logo",
  },
  {
    id: "kameryn-k",
    title: "Calmed My Nerves",
    content:
      "I used nexus to send my car from Washington to Florida and back again in 2021. Both times they were up front with the pricing, took very good care of my car and delivered the car earlier than expected. I was nervous to send my new car on an open truck across the country, but now I wouldn't think twice about using nexus to do it.",
    rating: "5.0",
    author: "Kameryn K.",
    logoAlt: "google-logo",
  },
  {
    id: "rafael-g",
    title: "Professional, Amazing Prices",
    content:
      "Process was very professional, the driver was always a call away, we had a small hiccup with the pickup but the driver worked with me and made this whole process extremely smooth. Amazing prices compared to competitors.",
    rating: "5.0",
    author: "Rafael G.",
    logoAlt: "google-logo",
  },
  {
    id: "shama-f",
    title: "No Hassles, Great Communication",
    content:
      "I shipped two cars all the way from west coast to east coast, and both cars were transported with no hassle from the day I booked with Nexus. Customer support was always easily available on phone, once a driver was assigned, their dispatch team was also very communicative. One of my cars were delivered in two days, I wasn't really expecting it to be this fast.",
    rating: "5.0",
    author: "Shama F.",
    logoAlt: "google-logo",
  },
  {
    id: "nana-q",
    title: "Best in the Game",
    content:
      "So far the best in the game. I have used them on three occasions and haven't been disappointed! Thanks guys!",
    rating: "5.0",
    author: "Nana Q.",
    logoAlt: "google-logo",
  },
  {
    id: "donny-w",
    title: "Easy, Unexpected Deal",
    content:
      "Arranged to have my 1982 Volvo 242 shipped over the phone. The shipping company called and made it easy to schedule the pickup. The driver was great. To my surprise it was an enclosed hauler for a very affordable price. Will definitely use Nexus next time I need a car shipped!",
    rating: "5.0",
    author: "Donny W.",
    logoAlt: "google-logo",
  },
  {
    id: "julee-w",
    title: "Quick Response, Smooth Process",
    content:
      "Nexus responded quickly to my request and even though I gave them less than a week's notice, they were able to schedule my auto transport. Communication was open and the process was smooth",
    rating: "5.0",
    author: "Julee W.",
    logoAlt: "google-logo",
  },
  {
    id: "k-padgett",
    title: "A Deserved A+ Rating",
    content:
      "I did my research! Nexus Auto Transport has an A+ rating on the BBB and I agree! The contractor, Tony, picked up my car and was great with communicating with me along the way. The customer service was great as well with scheduling everything. The price was fair and the service was great! Be cautious with those other companies that under quote - you get what you pay for!",
    rating: "5.0",
    author: "K. Padgett",
    logoAlt: "google-logo",
  },
  {
    id: "chris-k",
    title: "Excellent, Friendly Service",
    content:
      "The communication was excellent, they made sure the vehicles were delivered quickly and they also coordinated with the pick up location, who was not ready on time. As soon as vehicles were ready, they picked up the same day and delivered the next morning. Driver was friendly and put vehicles right where we wanted them.",
    rating: "5.0",
    author: "Chris K.",
    logoAlt: "google-logo",
  },
  {
    id: "reginald-w",
    title: "Rare Level of Service",
    content:
      "Excellent service, efficiency, and care for my vehicle. Moving cross country was very difficult overall, but not in regards to my vehicle. Our driver was incredibly quick, careful, and caring whilst transporting our car. Customer service is excellent from this firm, which is very rare nowadays. I recommend this company with 0 apprehensions.",
    rating: "5.0",
    author: "Reginald W.",
    logoAlt: "google-logo",
  },
  {
    id: "allison-c",
    title: "BBB #4",
    content:
      "In the middle of a moving emergency, the dispatcher hustled for me and scheduled the pick-up of my 2020 Fusion the very next day. The agent offered me a very affordable rate which was hundreds of dollars cheaper than the first company I called. The truck-drivers and Nexus agent were kind people and just overall great in terms of service. I would definitely recommend using to anyone looking to move their car over a long distance",
    rating: "5.0",
    author: "Allison C.",
    logoAlt: "bbb-logo",
  },
  {
    id: "sonny-m",
    title: "Great Experience, Friendly",
    content:
      "Great experience with the delivery of vehicle. Professional and friendly. I appreciated that they stayed in touch with me to keep me posted on the delivery.",
    rating: "5.0",
    author: "Sonny M.",
    logoAlt: "google-logo",
  },
  {
    id: "alicia-j",
    title: "Flexible, Affordable, Fast",
    content:
      "This was the first time we shipped a car, so it was a little scary but it turned out great. Customer service was always helpful, the price was the best we found and the carrier that picked up our car was reliable and flexible. It was faster than expected and they were happy to change the drop off location (in the same town) at the last minute. Would recommend and use again.",
    rating: "5.0",
    author: "Alicia J.",
    logoAlt: "google-logo",
  },
  {
    id: "keith-s",
    title: "Planning Another Shipment",
    content:
      "Vehicles picked up and delivered on time, even with crazy supply chain issues and fuel prices. Decent rates, and reliable service. The driver who transported our car did a great job loading and unloading, and the car arrived a bit dirty but in perfect condition. I plan on calling them when we ship our car back in the spring.",
    rating: "5.0",
    author: "Keith S.",
    logoAlt: "google-logo",
  },
  {
    id: "lorie-mae-n",
    title: "Professional Next-Day Service",
    content:
      "So I needed my car shipped from California to NJ ASAP. I was able to get a driver the next day! They were very professional. I love that I could reach them anytime to talk to them about my car shipment. I've went through 3 different companies before a friend recommended them to me. .... Recommend. Will definitely use them again in the future.",
    rating: "5.0",
    author: "Lorie-Mae N.",
    logoAlt: "google-logo",
  },
  {
    id: "shayan-a",
    title: "Excellent, Efficient Service",
    content:
      "The employees at this company were very quick to communicate and arrange for a delivery of my Audi S7 all the way from Iowa to New Jersey, and they also did an excellent job at keeping me updated with the progress of the pick and delivery, I would highly recommend Nexus Auto Transport",
    rating: "5.0",
    author: "Shayan A.",
    logoAlt: "google-logo",
  },
  {
    id: "jan-k",
    title: "Transparent, Highly Recommended",
    content:
      "I was connected with a very reputable auto transport person. My contact with the initial gentlemen was excellent. He answered all my questions and explained how the process would work. There was follow-up contact to be sure my pick-up was scheduled and that all was satisfactory with the arrangements. I would definitely recommend Nexus Auto Transport to anyone in need of this type of service.",
    rating: "5.0",
    author: "Jan K.",
    logoAlt: "google-logo",
  },
  {
    id: "svetlana-c",
    title: "I am very happy",
    content:
      "I am very happy, with high quality service, which Nexus provided for me, to transfer my car from Michigan to Panama. These are honest and hard working people taking care of your car. Thank you to my friend who recommended Nexus to me.",
    rating: "5.0",
    author: "Svetlana C.",
    logoAlt: "tp-logo",
  },
  {
    id: "daryl-j-m",
    title: "Nexus Auto Transport's Outstanding Service!",
    content:
      "Nexus Auto Transport's customer service was outstanding. They anticipated every concern and responded to my questions promptly and courteously. I recommend them without hesitation, as my vehicle was delivered safely and without incident ahead of schedule.",
    rating: "5.0",
    author: "Daryl J. M.",
    logoAlt: "tp-logo",
  },
  {
    id: "bracken-m",
    title: "Hassle-Free Car Delivery",
    content:
      "Great service. Fast delivery time. Hassle free car delivery. And great prices. Will definitely continue to use them",
    rating: "5.0",
    author: "Bracken M.",
    logoAlt: "google-logo",
  },
  {
    id: "darrin-s",
    title: "Rough Weather, No Problem",
    content:
      "I had an excellent experience and would recommend them highly. They transported my daughter's classic Miata that only has 35,000 miles on it. It was delivered in the exact same shape as it was picked up (From Southern California to Seattle) even through rough weather!!!\n    Can't say enough good things about Nexus Auto Transport!!!",
    rating: "5.0",
    author: "Darrin S.",
    logoAlt: "google-logo",
  },
  {
    id: "conrad-j",
    title: "On Time, Safe and Sound",
    content:
      "I recently hired Nexus to haul a collector car from Iowa to Washington for me. The driver showed up when he said he would, was friendly, and did a great job dropping my car off on the day and at the place he said he would, safe and sound. I would work with Nexus again.",
    rating: "5.0",
    author: "Conrad J.",
    logoAlt: "google-logo",
  },
  {
    id: "david-b",
    title: "Effortless and Transparent",
    content:
      "Nexus provided me with awesome service. From beginning to end of the transport, the company was very professional and made the process effortless. I really appreciated the communication letting me know when it was picked up and when it was waiting at my home being delivered. Highly recommend this company for your auto transport needs.",
    rating: "5.0",
    author: "David B.",
    logoAlt: "google-logo",
  },
  {
    id: "jacori-j",
    title: "Earned a Repeat Customer",
    content:
      "I recently purchased a pre-owned vehicle here in Gilbert, AZ and needed a reliable Auto Transportation company to pick up and deliver my vehicle to Sacramento, CA safely. Richard from Nexus was great and provided on-time delivery for me. The driver was professional and handled my vehicle with care just as I expected. I use transportation service at least twice a year and Nexus will be my choice of Auto Transportation from now on. Thank you Nexus!!",
    rating: "5.0",
    author: "Jacori J.",
    logoAlt: "google-logo",
  },
  {
    id: "tony-m",
    title: "No More Shopping Around",
    content:
      "Nexus found a driver very quickly and for a cheaper price to ship a vehicle cross country (AZ to GA). Driver was very professional and delivered the vehicle on-time and without issue. I have used other transport companies in the past but I will use Nexus from now on. Great job to the Nexus team.",
    rating: "5.0",
    author: "Tony M.",
    logoAlt: "google-logo",
  },
  {
    id: "stephanie-s",
    title: "Friendly, Reasonable Prices",
    content:
      "I have used Nexus Auto Transport twice now to ship a vehicle from Florida to Michigan and both experiences have been great. Friendly professional service and reasonable prices. Easy communication with company and driver. Would recommend this car transport company.",
    rating: "5.0",
    author: "Stephanie S.",
    logoAlt: "google-logo",
  },
  {
    id: "abel-s",
    title: "Fair Pricing, Fast Delivery",
    content:
      "Used Nexus twice. They delivered early/on time both times. Fair pricing and fast delivery. I recommend their team and will be using them in the future. Honestly still shocked I got my first delivery done in one day and the other one in two days.",
    rating: "5.0",
    author: "Abel S.",
    logoAlt: "google-logo",
  },
];
