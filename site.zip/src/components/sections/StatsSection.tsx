import React from "react";

export function StatsSection() {
  return (
    <section className="bg-blue-950 box-border caret-transparent">
      <div className="box-border caret-transparent max-w-none w-full mx-auto px-3 md:max-w-[1140px]">
        <div className="box-border caret-transparent flex flex-wrap justify-center py-[30px]">
          <div className="box-border caret-transparent basis-full min-h-[auto] min-w-[auto] text-center mt-5 mb-6 mx-5 md:basis-[21%] md:mt-6">
            <div className="box-border caret-transparent">
              <span className="text-white text-[51px] font-semibold box-border caret-transparent leading-[84px]">
                10+
              </span>
            </div>
            <div className="text-white text-lg font-semibold box-border caret-transparent leading-[34px] md:text-[22px]">
              <span className="text-lg box-border caret-transparent md:text-[22px]">
                Years in Business
              </span>
            </div>
          </div>
          <div className="box-border caret-transparent basis-full min-h-[auto] min-w-[auto] text-center mt-5 mb-6 mx-5 md:basis-[21%] md:mt-6">
            <div className="box-border caret-transparent">
              <span className="text-white text-[51px] font-semibold box-border caret-transparent leading-[84px]">
                500,000+
              </span>
            </div>
            <div className="text-white text-lg font-semibold box-border caret-transparent leading-[34px] md:text-[22px]">
              <span className="text-lg box-border caret-transparent md:text-[22px]">
                Customers Served
              </span>
            </div>
          </div>
          <div className="box-border caret-transparent basis-full min-h-[auto] min-w-[auto] text-center mt-5 mb-6 mx-5 md:basis-[21%] md:mt-6">
            <div className="box-border caret-transparent">
              <span className="text-white text-[51px] font-semibold box-border caret-transparent leading-[84px]">
                16,000+
              </span>
            </div>
            <div className="text-white text-lg font-semibold box-border caret-transparent leading-[34px] md:text-[22px]">
              <span className="text-lg box-border caret-transparent md:text-[22px]">
                Car Hauler Partners
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
