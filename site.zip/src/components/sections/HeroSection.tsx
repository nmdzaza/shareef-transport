import React, { useState } from "react";
import { vehicleSizes } from "../../data/vehicleSizes";

type ActiveTab = "calculate" | "track";

const pickupDateOptions = [
  "As soon as possible",
  "Within 7 days",
  "On a particular date",
  "I don't know yet",
];

export function HeroSection() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("calculate");

  return (
    <div className="bg-sky-900 bg-none bg-no-repeat bg-cover box-border caret-transparent pt-20 pb-2.5 md:bg-[url('https://c.animaapp.com/mnnx669pIjQjBB/assets/bg-2026.webp')] md:pt-[180px] md:pb-[60px]">
      <div className="box-border caret-transparent max-w-none w-full mx-auto px-3 md:max-w-[1140px]">
        <div className="box-border caret-transparent grid [grid-template-areas:'title''calc''phone-wrapper''socials''subtitle'] grid-cols-[1fr] grid-rows-[auto] justify-between gap-y-3 md:[grid-template-areas:'._calc''title_calc''subtitle_calc''phone-wrapper_calc''socials_calc''._calc'] md:grid-cols-[55%_42%] md:grid-rows-[1fr_auto_auto_auto_auto_1fr] md:gap-y-[normal]">
          <div className="box-border caret-transparent col-end-[title] col-start-[title] row-end-[title] row-start-[title] min-h-[auto] min-w-[auto] text-center mt-3 md:text-start md:mt-0">
            <h1 className="text-white text-2xl font-bold box-border caret-transparent leading-9 text-center mb-0 md:text-[44px] md:leading-[66px] md:text-start md:mb-5">
              Ship a car with a reliable auto transport company
            </h1>
          </div>
          <div className="box-border caret-transparent col-end-[subtitle] col-start-[subtitle] row-end-[subtitle] row-start-[subtitle] min-h-[auto] min-w-[auto]">
            <span className="text-white text-[17px] box-border caret-transparent leading-[34px]">
              For over a decade, Nexus Auto Transport has been a trusted leader
              in nationwide vehicle shipping. We've successfully served more
              than 500,000 customers, delivering reliable service backed by an
              experienced support team. Fully licensed and certified by the
              FMCSA and U.S. Department of Transportation, we ship with safety
              and compliance at the forefront.
            </span>
          </div>
          <div className="box-border caret-transparent gap-x-3 flex flex-col-reverse col-end-[phone-wrapper] col-start-[phone-wrapper] row-end-[phone-wrapper] row-start-[phone-wrapper] justify-between min-h-[auto] min-w-[auto] gap-y-3 mt-4 md:gap-x-[normal] md:flex-row md:gap-y-[normal] md:mt-[30px]">
            <div className="text-white font-semibold box-border caret-transparent basis-[51%] leading-[19.2px] min-h-[auto] min-w-[auto] md:text-neutral-800 md:font-normal">
              <span className="text-white text-[13px] font-bold box-border caret-transparent leading-[15.6px]">
                Talk to a senior transport coordinator with 5+ years of hands-on
                shipping experience — call now for expert guidance.
              </span>
            </div>
            <div className="font-bold items-center box-border caret-transparent flex basis-[45%] justify-center min-h-[auto] min-w-[auto] border-lime-200 p-1 rounded-bl rounded-br rounded-tl rounded-tr border-[3px] border-solid md:font-normal">
              <a
                href="tel://224-218-2949"
                className="text-lime-200 text-xl font-bold items-center box-border caret-transparent flex justify-center leading-[30px] min-h-[auto] min-w-[auto] md:text-[28px] md:leading-[42px]"
              >
                <img
                  src="https://c.animaapp.com/mnnx669pIjQjBB/assets/headset-green.svg"
                  alt="headset icon"
                  className="text-xl box-border caret-transparent leading-[30px] max-w-full min-h-[auto] min-w-[auto] mr-3 md:text-[28px] md:leading-[42px]"
                />
                <span className="text-xl box-border caret-transparent block leading-[30px] min-h-[auto] min-w-[auto] md:text-[28px] md:leading-[42px]">
                  224-218-2949
                </span>
              </a>
            </div>
          </div>
          <div className="self-center box-border caret-transparent hidden col-start-1 row-end-[-1] row-start-1 min-h-0 min-w-0 opacity-0 pointer-events-none transform-none invisible md:block md:min-h-[auto] md:min-w-[auto] md:scale-95">
            <div className="box-border caret-transparent">
              <div className="text-white text-[15px] font-semibold items-center box-border caret-transparent gap-x-3 flex flex-wrap justify-center leading-[22.5px] min-h-[50px] gap-y-3 mb-2.5"></div>
              <div className="box-border caret-transparent leading-[0px]">
                <img
                  src="https://c.animaapp.com/mnnx669pIjQjBB/assets/icon-2.svg"
                  alt="Icon"
                  className="box-border caret-transparent w-full"
                />
              </div>
            </div>
            <div className="items-end box-border caret-transparent gap-x-4 flex opacity-0 gap-y-4 transform-none mt-7 md:translate-y-2.5">
              <span className="text-white text-sm font-bold items-center bg-white/40 box-border caret-transparent gap-x-[5px] flex shrink-0 tracking-[0.5px] leading-[21px] min-h-0 min-w-0 gap-y-[5px] px-2.5 py-1 rounded-bl rounded-br rounded-tl rounded-tr md:min-h-[auto] md:min-w-[auto]">
                <img
                  src="https://c.animaapp.com/mnnx669pIjQjBB/assets/icon-3.svg"
                  alt="Icon"
                  className="box-border caret-transparent shrink-0 h-[18px] w-3.5"
                />
                <span className="box-border caret-transparent block min-h-0 min-w-0 md:min-h-[auto] md:min-w-[auto]"></span>
              </span>
              <div className="relative box-border caret-transparent basis-[0%] grow h-[76px] min-h-0 min-w-0 overflow-hidden md:min-h-[auto] md:min-w-[auto]"></div>
              <span className="text-white text-sm font-bold items-center bg-white/40 box-border caret-transparent gap-x-[5px] flex shrink-0 tracking-[0.5px] leading-[21px] min-h-0 min-w-0 gap-y-[5px] px-2.5 py-1 rounded-bl rounded-br rounded-tl rounded-tr md:min-h-[auto] md:min-w-[auto]">
                <img
                  src="https://c.animaapp.com/mnnx669pIjQjBB/assets/icon-3.svg"
                  alt="Icon"
                  className="box-border caret-transparent shrink-0 h-[18px] w-3.5"
                />
                <span className="box-border caret-transparent block min-h-0 min-w-0 md:min-h-[auto] md:min-w-[auto]"></span>
              </span>
            </div>
          </div>
          <div className="box-border caret-transparent col-end-[socials] col-start-[socials] row-end-[socials] row-start-[socials] min-h-[auto] min-w-[auto] mt-0 md:mt-[30px]">
            <div className="box-border caret-transparent gap-x-4 flex justify-center gap-y-4 mb-5 md:justify-normal md:mb-0">
              <div className="box-border caret-transparent min-h-[auto] min-w-[auto]">
                <a
                  href="https://www.facebook.com/nexusautotransport"
                  className="text-blue-600 box-border caret-transparent"
                >
                  <img
                    src="https://c.animaapp.com/mnnx669pIjQjBB/assets/fb.webp"
                    alt="facebook logo"
                    className="box-border caret-transparent inline max-w-full"
                  />
                </a>
              </div>
              <div className="box-border caret-transparent min-h-[auto] min-w-[auto]">
                <a
                  href="https://www.youtube.com/channel/UCc1Uc_3LjlnSUF0EKEKNBOA"
                  className="text-blue-600 box-border caret-transparent"
                >
                  <img
                    src="https://c.animaapp.com/mnnx669pIjQjBB/assets/yt.webp"
                    alt="youtube logo"
                    className="box-border caret-transparent inline max-w-full"
                  />
                </a>
              </div>
              <div className="box-border caret-transparent min-h-[auto] min-w-[auto]">
                <a
                  href="https://www.linkedin.com/company/nexusautotransport/"
                  className="text-blue-600 box-border caret-transparent"
                >
                  <img
                    src="https://c.animaapp.com/mnnx669pIjQjBB/assets/in.webp"
                    alt="linkedin logo"
                    className="box-border caret-transparent inline max-w-full"
                  />
                </a>
              </div>
              <div className="box-border caret-transparent min-h-[auto] min-w-[auto]">
                <a
                  href="https://www.instagram.com/nexus.car.shipping/"
                  className="text-blue-600 box-border caret-transparent"
                >
                  <img
                    src="https://c.animaapp.com/mnnx669pIjQjBB/assets/ig.webp"
                    alt="instagram logo"
                    className="box-border caret-transparent inline max-w-full"
                  />
                </a>
              </div>
            </div>
          </div>
          <div className="box-border caret-transparent col-end-[calc] col-start-[calc] row-end-[calc] row-start-[calc] min-h-[auto] min-w-[auto]">
            <div className="box-border caret-transparent">
              <div className="relative bg-slate-50 shadow-[rgba(0,0,0,0.08)_0px_4px_24px_0px] box-border caret-transparent rounded-lg">
                <div className="box-border caret-transparent flex overflow-hidden rounded-t-lg">
                  <button
                    className="relative text-blue-950 text-[13px] font-bold items-center bg-slate-50 caret-transparent gap-x-2 flex basis-[0%] grow justify-center leading-[19.5px] min-h-[auto] min-w-[auto] gap-y-2 text-center overflow-hidden px-4 py-[18px] md:text-base md:leading-6"
                    onClick={() => setActiveTab("calculate")}
                  >
                    <img
                      src="https://c.animaapp.com/mnnx669pIjQjBB/assets/icon-6.svg"
                      alt="Icon"
                      className="text-[13px] box-border caret-transparent h-5 leading-[19.5px] w-5 md:text-base md:leading-6"
                    />
                    Calculate Shipping
                  </button>
                  <button
                    className="relative text-neutral-600 text-[13px] font-bold items-center bg-zinc-200 caret-transparent gap-x-2 flex basis-[0%] grow justify-center leading-[19.5px] min-h-[auto] min-w-[auto] gap-y-2 text-center overflow-hidden px-4 py-[18px] md:text-base md:leading-6 after:accent-auto after:shadow-[rgb(0,0,0)_0px_0px_10px_0px] after:box-border after:caret-transparent after:text-neutral-600 after:block after:text-[13px] after:not-italic after:normal-nums after:font-bold after:h-full after:tracking-[normal] after:leading-[19.5px] after:list-outside after:list-disc after:pointer-events-auto after:absolute after:text-center after:no-underline after:indent-[0px] after:normal-case after:visible after:w-px after:border-separate after:left-0 after:font-montserrat after:md:text-base after:md:leading-6"
                    onClick={() => setActiveTab("track")}
                  >
                    <img
                      src="https://c.animaapp.com/mnnx669pIjQjBB/assets/icon-7.svg"
                      alt="Icon"
                      className="text-[13px] box-border caret-transparent h-5 leading-[19.5px] opacity-50 w-5 md:text-base md:leading-6"
                    />
                    Track a Shipment
                  </button>
                </div>
                <div className="box-border caret-transparent pt-3 px-3 md:pt-7 md:px-[26px]">
                  <form className="box-border caret-transparent">
                    <h2 className="text-blue-950 text-base font-bold box-border caret-transparent leading-[21.6px] mb-[22px] md:text-lg md:leading-[24.3px]">
                      Quote From Senior Auto Transport Experts
                    </h2>
                    <div className="text-blue-950 font-bold items-center box-border caret-transparent gap-x-2 flex gap-y-2 mb-3.5">
                      <img
                        src="https://c.animaapp.com/mnnx669pIjQjBB/assets/icon-8.svg"
                        alt="Icon"
                        className="box-border caret-transparent h-6 w-[25px]"
                      />
                      <span className="box-border caret-transparent block min-h-[auto] min-w-[auto]">
                        Route
                      </span>
                    </div>
                    <div className="box-border caret-transparent gap-x-3 flex flex-col gap-y-3 mb-3">
                      <div className="relative box-border caret-transparent min-h-[auto] min-w-[auto]">
                        <label className="box-border caret-transparent hidden">
                          Pickup Location
                        </label>
                        <input
                          type="text"
                          name="pickup"
                          placeholder="From (ZIP or City, State)"
                          className="text-blue-950 font-semibold box-border caret-transparent w-full border border-zinc-300 px-[18px] py-[15px] rounded-[10px] border-solid"
                        />
                        <div className="absolute bg-white border-b-zinc-300 border-l-zinc-300 border-r-zinc-300 border-t-neutral-800 shadow-[rgba(0,0,0,0.08)_0px_8px_16px_0px] box-border caret-transparent hidden max-h-60 z-[100] overflow-auto rounded-b-[10px] border-b border-l border-r top-full inset-x-0"></div>
                      </div>
                      <div className="relative box-border caret-transparent min-h-[auto] min-w-[auto]">
                        <label className="box-border caret-transparent hidden">
                          Delivery Location
                        </label>
                        <input
                          type="text"
                          name="delivery"
                          placeholder="To (ZIP or City, State)"
                          className="text-blue-950 font-semibold box-border caret-transparent w-full border border-zinc-300 px-[18px] py-[15px] rounded-[10px] border-solid"
                        />
                        <div className="absolute bg-white border-b-zinc-300 border-l-zinc-300 border-r-zinc-300 border-t-neutral-800 shadow-[rgba(0,0,0,0.08)_0px_8px_16px_0px] box-border caret-transparent hidden max-h-60 z-[100] overflow-auto rounded-b-[10px] border-b border-l border-r top-full inset-x-0"></div>
                      </div>
                    </div>
                    <div className="text-blue-950 font-bold items-center box-border caret-transparent gap-x-2 flex gap-y-2 mb-3.5">
                      <img
                        src="https://c.animaapp.com/mnnx669pIjQjBB/assets/icon-9.svg"
                        alt="Icon"
                        className="box-border caret-transparent h-6 w-[25px]"
                      />
                      <span className="box-border caret-transparent block min-h-[auto] min-w-[auto]">
                        Shipping
                      </span>
                    </div>
                    <div className="box-border caret-transparent gap-x-3 flex flex-col gap-y-3 mb-3">
                      <div className="relative box-border caret-transparent min-h-[auto] min-w-[auto]">
                        <label className="box-border caret-transparent hidden">
                          Vehicle Size
                        </label>
                        <div className="relative box-border caret-transparent">
                          <button
                            type="button"
                            className="text-slate-400 font-medium items-center bg-white caret-transparent gap-x-2.5 flex justify-between gap-y-2.5 text-center w-full border border-zinc-300 px-[18px] py-[15px] rounded-[10px]"
                          >
                            <span className="box-border caret-transparent block min-h-[auto] min-w-[auto]">
                              Size of Car
                            </span>
                            <img
                              src="https://c.animaapp.com/mnnx669pIjQjBB/assets/icon-10.svg"
                              alt="Icon"
                              className="text-blue-950 box-border caret-transparent shrink-0 h-3 w-3"
                            />
                          </button>
                          <div className="absolute bg-white border-b-zinc-300 border-l-zinc-300 border-r-zinc-300 border-t-neutral-800 shadow-[rgba(0,0,0,0.08)_0px_8px_16px_0px] box-border caret-transparent hidden max-h-[280px] z-50 overflow-auto py-1.5 rounded-b-[10px] border-b border-l border-r top-full inset-x-0">
                            {vehicleSizes.map((vehicle) => (
                              <div
                                key={vehicle.id}
                                className="items-center box-border caret-transparent gap-x-3 flex gap-y-3 px-[18px] py-2.5"
                              >
                                <img
                                  src={vehicle.imageUrl}
                                  alt="Icon"
                                  className="box-border caret-transparent shrink-0 h-[30px] w-12"
                                />
                                <span className="text-blue-950 font-semibold box-border caret-transparent block">
                                  {vehicle.label}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                        <input
                          type="hidden"
                          name="vehicle"
                          className="appearance-none text-black bg-transparent box-border caret-transparent hidden p-0"
                        />
                        <input
                          type="hidden"
                          name="vehicle_key"
                          className="appearance-none text-black bg-transparent box-border caret-transparent hidden p-0"
                        />
                      </div>
                      <div className="relative box-border caret-transparent min-h-[auto] min-w-[auto]">
                        <label className="box-border caret-transparent hidden">
                          Pickup Date
                        </label>
                        <div className="relative box-border caret-transparent">
                          <button
                            type="button"
                            className="text-slate-400 font-medium items-center bg-white caret-transparent flex justify-between text-center w-full border border-zinc-300 px-[18px] py-[15px] rounded-[10px]"
                          >
                            <span className="box-border caret-transparent block min-h-[auto] min-w-[auto]">
                              Pickup Date
                            </span>
                            <img
                              src="https://c.animaapp.com/mnnx669pIjQjBB/assets/icon-27.svg"
                              alt="Icon"
                              className="text-blue-950 box-border caret-transparent h-3 w-3"
                            />
                          </button>
                          <div className="absolute bg-white border-b-zinc-300 border-l-zinc-300 border-r-zinc-300 border-t-neutral-800 shadow-[rgba(0,0,0,0.08)_0px_8px_16px_0px] box-border caret-transparent hidden z-50 rounded-b-[10px] border-b border-l border-r top-full inset-x-0">
                            {pickupDateOptions.map((option) => (
                              <div
                                key={option}
                                className="text-blue-950 font-semibold box-border caret-transparent px-[18px] py-2.5"
                              >
                                {option}
                              </div>
                            ))}
                          </div>
                        </div>
                        <div className="relative box-border caret-transparent hidden"></div>
                        <input
                          type="hidden"
                          name="time"
                          className="appearance-none text-black bg-transparent box-border caret-transparent hidden p-0"
                        />
                      </div>
                    </div>
                    <div className="box-border caret-transparent mt-2 mb-3.5">
                      <button
                        type="button"
                        className="text-blue-500 text-sm font-semibold bg-transparent caret-transparent leading-[21px] text-center align-middle px-3 py-1.5 rounded-md"
                      >
                        + Add More Vehicles
                      </button>
                    </div>
                    <div className="items-center box-border caret-transparent gap-x-2.5 flex gap-y-2.5 mb-[18px]">
                      <input
                        type="checkbox"
                        name="is-dealer"
                        value="1"
                        className="text-black accent-blue-500 bg-transparent box-border caret-transparent block shrink-0 h-5 min-h-[auto] min-w-[auto] w-5 overflow-visible p-0"
                      />
                      <label className="text-blue-950 text-[15px] font-medium box-border caret-transparent block leading-[22.5px] min-h-[auto] min-w-[auto]">
                        Are you an automotive dealer?
                      </label>
                    </div>
                    <div className="box-border caret-transparent flex flex-col">
                      <button
                        type="submit"
                        className="text-blue-950 font-semibold bg-lime-300 caret-transparent block tracking-[-0.16px] mb-[-1.5px] min-h-[auto] min-w-[auto] text-center w-[calc(100%_+_24px)] -ml-3 p-[18px] rounded-b-lg md:ml-[-26px] md:w-[calc(100%_+_52px)]"
                      >
                        America's Trusted Shipper — Quote Now
                      </button>
                    </div>
                  </form>
                </div>
                <div className="box-border caret-transparent hidden pt-3 px-3 md:pt-7 md:px-[26px]">
                  <div className="box-border caret-transparent">
                    <p className="font-bold box-border caret-transparent mb-4">
                      Order Details
                    </p>
                    <form className="box-border caret-transparent">
                      <input
                        type="hidden"
                        name="CRAFT_CSRF_TOKEN"
                        value="2VvSb_1WwaTIkkZK2148eg49KXrQw3-rQpnNeYI7g2azEEKPTaH3PLYrmz6nCYDNptgeIeIHCkNIdH87v_MGzQ3upSrFefJf3Xkw0APoj38="
                        className="appearance-none text-black bg-transparent box-border caret-transparent hidden p-0"
                      />
                      <input
                        type="hidden"
                        name="action"
                        value="contact-form/send"
                        className="appearance-none text-black bg-transparent box-border caret-transparent hidden p-0"
                      />
                      <input
                        type="hidden"
                        name="subject"
                        value="Shipment Tracking Request"
                        className="appearance-none text-black bg-transparent box-border caret-transparent hidden p-0"
                      />
                      <input
                        type="hidden"
                        name="message[body]"
                        value="Shipment Tracking Request"
                        className="appearance-none text-black bg-transparent box-border caret-transparent hidden p-0"
                      />
                      <div className="relative box-border caret-transparent mb-3">
                        <label className="text-blue-950 text-[13px] font-semibold box-border caret-transparent block leading-[19.5px] mb-1.5">
                          Email Address
                        </label>
                        <input
                          type="email"
                          name="fromEmail"
                          placeholder="Your E-mail Address"
                          className="text-blue-950 font-semibold box-border caret-transparent w-full border border-zinc-300 px-[18px] py-[15px] rounded-[10px] border-solid"
                        />
                      </div>
                      <div className="relative box-border caret-transparent mb-3">
                        <label className="text-blue-950 text-[13px] font-semibold box-border caret-transparent block leading-[19.5px] mb-1.5">
                          Order Detail
                        </label>
                        <input
                          type="text"
                          name="message[Order_Detail]"
                          placeholder="Your name or order number"
                          className="text-blue-950 font-semibold box-border caret-transparent w-full border border-zinc-300 px-[18px] py-[15px] rounded-[10px] border-solid"
                        />
                      </div>
                      <div className="box-border caret-transparent mt-4"></div>
                      <button
                        type="submit"
                        className="text-blue-950 font-semibold bg-lime-300 caret-transparent block tracking-[-0.16px] mb-[-1.5px] text-center w-[calc(100%_+_24px)] -ml-3 mt-4 p-[18px] rounded-b-lg md:ml-[-26px] md:w-[calc(100%_+_52px)]"
                      >
                        Track Shipment
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
